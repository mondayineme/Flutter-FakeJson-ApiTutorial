package com.example.flutter_company_record_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
