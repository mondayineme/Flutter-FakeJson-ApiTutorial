import 'address.dart';
import 'company.dart';

class User{
  int id;
  String name;
  String username;
  String email;
  Address address;
  String phone;
  String website;
  Company company;

  User({required this.id, required this.name, required this.username, required this.email, required this.address, required this.phone,
    required this.website, required this.company});

  factory User.fromJSON(Map<String, dynamic> jsonData){
    return User(
        id: jsonData['id'],
        name: jsonData['name'],
        username: jsonData['username'],
        email: jsonData['email'],
        phone: jsonData['phone'],
        website: jsonData['website'],
        address: Address.fromJSON(jsonData['address']),
        company: Company.fromJSON(jsonData['company'])
    );
  }
}