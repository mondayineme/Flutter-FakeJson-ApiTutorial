class Company {
  String name;
  String catchPhrase;
  String bs;

  Company({required this.name, required this.catchPhrase, required this.bs});

  factory Company.fromJSON(Map<String, dynamic> jsonData) {
    return Company(
        name: jsonData['name'],
        catchPhrase: jsonData['catchPhrase'],
        bs: jsonData['bs']);
  }
}
