import 'package:flutter/material.dart';
import 'package:flutter_company_record_api/models/user.dart';

import 'api_service/api_call.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter FakeJson ApiTutorial',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.black,
        title: const Text("Flutter FakeJson ApiTutorial"),
      ),
      body: FutureBuilder<List>(
        future: getUsers(),
        builder: (context, snapshot){
          if(snapshot.hasData){
            return ListView.builder(
              itemCount: snapshot.data!.length,
                itemBuilder: (context, index){

                User user = User.fromJSON(snapshot.data![index]);

                return Container(
                  padding: const EdgeInsets.all(10),
                  child: Card(
                    margin: const EdgeInsets.all(5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(user.name, style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          color: Colors.black
                        ),),
                        const SizedBox(height: 5,),
                        Text(user.email, style: const TextStyle(
                          color: Colors.pinkAccent
                        ),),
                        const SizedBox(height: 5,),
                        Text("${user.address.street} ${user.address.suite} ${user.address.city} ${user.address.zipcode}"),
                        const SizedBox(height: 5,),
                        Text(user.phone),
                        const SizedBox(height: 5,),
                        Text(user.website),
                        const SizedBox(height: 5,),
                        Text(user.company.name),
                        const SizedBox(height: 5,),
                        Text(user.company.catchPhrase)
                      ],
                    ),
                  ),
                );

                }
            );
          }else if(snapshot.hasError){
            return Center(
              child: Text("${snapshot.error}"),
            );
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}
